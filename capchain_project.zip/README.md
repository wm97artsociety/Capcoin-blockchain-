
# CapChain Blockchain Project

## Overview
CapChain is a blockchain-based system where users earn cryptocurrency (CAPCOIN) by scanning real-world bottle caps.

## Components
- Smart Contract (`CapCoin.sol`): Handles minting, volatility locking, and token logic.
- Mobile App (React Native): Scans caps and submits them to the backend.
- Backend (Node.js): Validates scans, logs to Firebase and IPFS, and interacts with the smart contract.
- Firebase: Stores scanned cap data securely.
- IPFS: Decentralized storage of cap metadata.

## Volatility Logic
- If CAPCOIN price drops 7%, selling is frozen.
- Selling is unlocked only after a 14% recovery from the dip.

## Usage Flow
1. Scan a bottle cap via the app.
2. Cap ID sent to backend.
3. Backend checks uniqueness and logs it.
4. Token minted via smart contract.
5. Data logged to Firebase and IPFS.

## Deployment
- Use Hardhat to deploy `CapCoin.sol`.
- Start backend server with `node server.js`.
- Launch the mobile app using React Native CLI.

