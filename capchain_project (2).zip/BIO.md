
# CapChain Software Bio (Updated for Unlimited Token Capability)

## 🚀 Overview
CapChain is a blockchain-powered reward system where anyone can earn cryptocurrency (CAPCOIN) by taking a picture of a real-world **bottle cap** and scanning it into the system. The system supports **unlimited token generation** so that every authentic bottle cap found, scanned, or collected can be converted into value—redeemable at ATMs or kiosks in the future.

---

## 💡 Core Idea
- Every bottle cap is unique and valuable.
- A user can **take a picture** of a cap (on the ground, in hand, etc.)
- The system mints CAPCOIN based on the **identity and perceived value** of that cap.
- Tokens are **redeemable at ATMs or kiosks** in the future.

---

## 🔧 Unlimited Token Logic

Unlike capped-supply models, CapChain’s smart contract is designed to:

- Allow **unlimited minting** of tokens upon valid cap scans
- Reward users based on **cap uniqueness, length of cap ID, or image fingerprint**
- Enable **detection of duplicate scans** to prevent abuse
- Provide **scalable token economics** that mimic penny stocks (pennyblock style)

---

## 📸 Picture-Driven Value System

When a user submits a picture of a cap:

1. The image is processed (locally or via backend OCR)
2. A `capID` or visual hash is generated
3. Value is determined based on:
    - Cap rarity (brand, age, series)
    - Metadata length/complexity
    - Optional AI image classifier score (for rare caps)
4. Tokens are minted and sent to user’s wallet

---

## 🏧 Kiosk/ATM Integration (Planned)

CapChain’s backend is architected to support future:
- ATM hardware or smart kiosks where:
  - Users deposit caps physically
  - Cameras confirm via visual match
  - Tokens are withdrawn as cash or spendable balance

---

## ✅ Key Features Summary

| Feature                | Description |
|------------------------|-------------|
| Unlimited Tokens       | Every valid scan mints new tokens |
| Image Recognition      | Bottle cap images create unique ID hashes |
| IPFS Logging           | Cap metadata is stored permanently and trustlessly |
| Firebase Secured Logs  | Cap scans and metadata are also written to Firestore |
| Mobile + Kiosk Ready   | Designed for phone use now, kiosk use later |
| Volatility Protection  | 7% sell dip lock, 14% recovery unlock |

---

## 🌐 User Flow

1. **User finds bottle cap**
2. **Takes picture through app**
3. **Image analyzed → `capID` generated**
4. **Smart contract mints CAPCOIN**
5. **CAPCOIN stored in user wallet**
6. **(Optional)** Cap metadata logged to IPFS + Firebase
7. **User redeems tokens online or at physical kiosk**

---

## 🧱 Stack

- Smart Contract: Solidity + Hardhat
- Backend: Node.js + Express + ethers.js + IPFS + Firebase
- Mobile: React Native
- Token: CAPCOIN (ERC-20), unlimited supply, dynamic minting
