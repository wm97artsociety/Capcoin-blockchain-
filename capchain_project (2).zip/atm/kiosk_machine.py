
# ATM / Kiosk Machine Software for CapChain
# Language: Python (can run on Raspberry Pi or similar device)

import cv2
import requests
import time
from eth_account import Account

# Simulated camera feed to capture image of bottle cap
def capture_bottle_cap_image():
    cap = cv2.VideoCapture(0)
    print("Capturing bottle cap... Please place it in front of the camera.")
    time.sleep(2)
    ret, frame = cap.read()
    filename = "captured_cap.jpg"
    if ret:
        cv2.imwrite(filename, frame)
        print(f"Image saved to {filename}")
    cap.release()
    return filename

# Simulated image hash for cap ID
def generate_cap_id_from_image(image_path):
    import hashlib
    with open(image_path, "rb") as f:
        image_data = f.read()
    return hashlib.sha256(image_data).hexdigest()

# Simulated user Ethereum wallet for cap deposit
USER_WALLET = "0xYourUserWalletHere"

# Simulate kiosk process
def process_kiosk_scan():
    image = capture_bottle_cap_image()
    cap_id = generate_cap_id_from_image(image)
    print(f"Generated cap ID: {cap_id}")

    # Send to backend for minting CAPCOIN
    response = requests.post("http://your-capchain-backend/scan-cap", json={
        "capID": cap_id,
        "userAddress": USER_WALLET,
        "scannerToken": "secure-admin-token"
    })

    if response.status_code == 200:
        print("CAPCOIN minted and sent to wallet!")
    else:
        print(f"Error: {response.text}")

if __name__ == "__main__":
    process_kiosk_scan()
