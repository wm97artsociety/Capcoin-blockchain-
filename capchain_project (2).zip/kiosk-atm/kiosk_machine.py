
# Kiosk Simulation for CapChain

import time

class CapKiosk:
    def __init__(self, rate_per_capcoin=0.000001):
        self.rate = rate_per_capcoin

    def scan_and_submit_cap(self, image_path):
        # Simulated image scan
        cap_id = f"IMG-{hash(image_path) % 10000000}"
        print(f"Scanned cap image. Generated capID: {cap_id}")
        minted_tokens = 1000  # Based on capID rules
        print(f"Minted {minted_tokens} CAPCOIN to user wallet")
        return cap_id, minted_tokens

    def display_balance_and_cashout(self, capcoin_balance):
        cash_value = capcoin_balance * self.rate
        print(f"Balance: {capcoin_balance} CAPCOIN → ${cash_value:.2f} available")
        return cash_value

if __name__ == "__main__":
    kiosk = CapKiosk()
    print("📷 Scanning bottle cap image...")
    cap_id, tokens = kiosk.scan_and_submit_cap("example_cap.jpg")
    kiosk.display_balance_and_cashout(tokens)
