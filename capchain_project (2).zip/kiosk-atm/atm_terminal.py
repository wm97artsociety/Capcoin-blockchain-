
# ATM Simulation for CapChain

import time

class CapATM:
    def __init__(self, rate_per_capcoin=0.000001):
        self.exchange_rate = rate_per_capcoin  # ETH equivalent or token-to-cash

    def validate_token_balance(self, wallet_address):
        # Simulated token check (would call blockchain in real version)
        print(f"Checking CAPCOIN balance for wallet: {wallet_address}")
        return 5000  # Example CAPCOIN

    def redeem_capcoins(self, wallet_address, capcoin_amount):
        if capcoin_amount <= 0:
            return "Invalid amount."
        balance = self.validate_token_balance(wallet_address)
        if capcoin_amount > balance:
            return "Insufficient CAPCOIN balance."
        # Simulated cash value conversion
        cash_value = capcoin_amount * self.exchange_rate
        print(f"Redeemed {capcoin_amount} CAPCOIN for ${cash_value:.2f} cash equivalent")
        return cash_value

if __name__ == "__main__":
    atm = CapATM()
    wallet = input("Enter wallet address: ")
    amount = int(input("Enter CAPCOIN to redeem: "))
    atm.redeem_capcoins(wallet, amount)
